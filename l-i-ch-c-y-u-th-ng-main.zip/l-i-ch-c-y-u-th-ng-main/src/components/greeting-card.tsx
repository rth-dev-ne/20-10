import { Heart } from "lucide-react";
import type { Ref } from "react";
import type { CardTemplate } from "@/lib/card-templates";

type GreetingCardProps = {
  recipient: { name: string; wish: string };
  template: CardTemplate;
  cardRef: Ref<HTMLDivElement>;
};

export function GreetingCard({ recipient, template, cardRef }: GreetingCardProps) {
  return (
    <div className={`greeting-card greeting-card--${template.id}`} ref={cardRef}>
      <img src={template.artwork} alt={template.alt} className="card-art" width={template.width} height={template.height} loading="lazy" />
      <div className="greeting-content">
        <div className="card-date">20 / 10</div>
        <div className="card-occasion">Ngày Phụ nữ Việt Nam</div>
        <h3>Gửi <span>{recipient.name}</span>,</h3>
        <p className="card-wish">{recipient.wish}</p>
        <Heart className="card-heart" strokeWidth={1.3} />
        <div className="card-from">Thương mến, những người bạn cùng lớp</div>
      </div>
    </div>
  );
}