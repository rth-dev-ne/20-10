import { describe, expect, it } from "vitest";
import { findGreeting, greetings } from "../lib/greetings";

const officialNames = [
  "Nguyễn Thị Lan Anh",
  "Trần Hoàng Khánh Băng",
  "Trần Gia Hân",
  "Hoàng Huỳnh Bảo Ngọc",
  "Trần Thị Ánh Ngọc",
  "Trương Bảo Ngọc",
  "Đỗ Kim Nguyên",
  "Nguyễn Hoàng Mỹ Phương",
  "Nguyễn Nhật Khánh Thi",
  "Dương Khánh Tường",
  "Phan Nguyễn Tường Vy",
  "Mẹ",
  "Bà",
];

describe("Recipient lookup", () => {
  it("contains the thirteen official recipients and nothing else", () => {
    expect(greetings.map((item) => item.name)).toEqual(officialNames);
  });
  it("keeps every recipient's wish unique and non-empty", () => {
    const wishes = greetings.map((item) => item.wish);
    expect(wishes.every((wish) => wish.trim().length > 60)).toBe(true);
    expect(new Set(wishes).size).toBe(13);
  });
  it("finds a full name despite casing and extra whitespace", () => {
    expect(findGreeting("  trần   hoàng KHÁNH BĂNG  ")?.name).toBe("Trần Hoàng Khánh Băng");
  });
  it("keeps the two Bảo Ngọc recipients separate by full name", () => {
    expect(findGreeting("Hoàng Huỳnh Bảo Ngọc")?.wish.startsWith("Tặng Bảo Ngọc một bó hoa")).toBe(true);
    expect(findGreeting("Trương Bảo Ngọc")?.wish.startsWith("Nhân ngày 20/10, gửi Bảo Ngọc một món quà")).toBe(true);
    expect(findGreeting("Bảo Ngọc")).toBeUndefined();
  });
  it("opens the Mother's Day card for the exact name Mẹ", () => {
    expect(findGreeting("Mẹ")?.wish).toBe("Mẹ yêu quý, chúc mẹ một ngày 20/10 thật nhiều niềm vui và bình an. Cảm ơn mẹ vì những yêu thương, chăm sóc và hy sinh thầm lặng dành cho gia đình. Mong mẹ luôn mạnh khỏe, giữ mãi nụ cười trên môi và có thật nhiều ngày tháng hạnh phúc bên những người mẹ yêu thương.");
  });
  it("opens the Grandmother's Day card for the exact name Bà", () => {
    expect(findGreeting("Bà")?.wish).toBe("Bà yêu quý, nhân ngày 20/10, cháu chúc bà luôn mạnh khỏe, vui vẻ và bình an. Mong mỗi ngày của bà đều có những niềm vui nhỏ, những tiếng cười ấm áp và thật nhiều khoảnh khắc hạnh phúc bên con cháu. Cháu mong bà luôn khỏe mạnh để gia đình mình có thêm thật nhiều ngày tháng sum vầy bên nhau.");
  });
  it("does not match a shorter form of Mẹ or Bà", () => {
    expect(findGreeting("Me")).toBeUndefined();
    expect(findGreeting("Ba")).toBeUndefined();
  });
  it("does not create a recipient for an unknown or empty name", () => {
    expect(findGreeting("Người chưa có thiệp")).toBeUndefined();
    expect(findGreeting("")).toBeUndefined();
  });
});
