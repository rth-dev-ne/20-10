import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { ArrowDown, ArrowRight, Check, ChevronDown, Download, Flower2, Heart, Mail, RotateCcw, Search, Sparkles } from "lucide-react";
import { toPng } from "html-to-image";
import { Button } from "@/components/ui/button";
import floralCard from "@/assets/floral-card.jpg";
import { findGreeting, greetings } from "@/lib/greetings";
import { cardTemplates } from "@/lib/card-templates";
import { GreetingCard } from "@/components/greeting-card";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Gửi chút yêu thương · Thiệp chúc mừng 20/10" },
    { name: "description", content: "Một món quà nhỏ dành riêng cho bạn. Mở những tấm thiệp hoa và lời chúc dịu dàng nhân ngày Phụ nữ Việt Nam 20/10." },
    { property: "og:title", content: "Gửi chút yêu thương · Thiệp chúc mừng 20/10" },
    { property: "og:description", content: "Gửi các bạn nữ trong lớp một tấm thiệp hoa cùng những lời chúc chân thành nhân ngày 20/10." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  const [name, setName] = useState("");
  const [recipient, setRecipient] = useState(greetings[0]);
  const [opened, setOpened] = useState(false);
  const [error, setError] = useState("");
  const [downloadState, setDownloadState] = useState<"idle" | "loading" | "done">("idle");
  const [downloadError, setDownloadError] = useState("");
  const [template, setTemplate] = useState<(typeof cardTemplates)[number]>(cardTemplates[0]);
  const sectionRef = useRef<HTMLElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const reveal = (sample = recipient) => {
    setRecipient(sample);
    setOpened(true);
    setDownloadState("idle");
    setDownloadError("");
    window.setTimeout(() => sectionRef.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" }), 80);
  };

  const search = (value: string) => {
    const found = findGreeting(value);
    if (!found) {
      setError(value.trim() ? "Chưa tìm thấy thiệp. Bạn hãy nhập đúng họ tên đầy đủ hoặc chọn một tên trong danh sách bên dưới nhé." : "Bạn hãy nhập hoặc chọn một tên trong danh sách nhé.");
      return;
    }
    setName(found.name);
    setError("");
    reveal(found);
  };

  const download = async () => {
    if (!cardRef.current || downloadState === "loading") return;
    setDownloadState("loading");
    setDownloadError("");
    try {
      await document.fonts.ready;
      const card = cardRef.current;
      if (!card) { setDownloadState("idle"); return; }
      await Promise.all(Array.from(card.querySelectorAll("img")).map((image) => image.decode()));
      const dataUrl = await toPng(card, { pixelRatio: 3, cacheBust: false, style: { animation: "none", transform: "none", opacity: "1" } });
      const link = document.createElement("a");
      link.download = `thiep-20-10-${recipient.name.replace(/\s+/g, "-")}.png`;
      link.href = dataUrl;
      link.click();
      setDownloadState("done");
    } catch {
      setDownloadError("Chưa tải được ảnh. Bạn hãy thử lại nhé.");
      setDownloadState("idle");
    }
  };

  return (
    <>
      <header className="site-header">
        <a href="/" className="brand" aria-label="Gửi chút yêu thương — trang chủ"><Flower2 strokeWidth={1.4} />Gửi chút yêu thương</a>
        <div className="header-note"><Heart strokeWidth={1.5} /><span>Dành cho những điều thật đặc biệt</span><span>20.10</span></div>
      </header>
      <main>
        <section className="hero">
          <img src={floralCard} alt="Những đóa hồng pastel và mẫu đơn trắng dịu dàng" className="hero-art" width={1536} height={1024} />
          <div className="hero-content">
            <div className="date-label">Chúc mừng ngày Phụ nữ Việt Nam</div>
            <h1>Một món quà nhỏ<br />dành riêng <em>cho bạn</em></h1>
            <p className="hero-intro">Có những điều dễ thương không cần nói thành lời.<br />Một tấm thiệp, một chút yêu thương — gửi đến bạn<br className="hidden sm:block" /> trong ngày đặc biệt này.</p>
            <Button variant="romantic" onClick={() => reveal()}><Mail strokeWidth={1.6} />Mở thiệp<ArrowRight strokeWidth={1.5} /></Button>
            <div className="hero-signoff"><Heart strokeWidth={1.3} />Từ những người bạn cùng lớp, với tất cả chân thành</div>
            <div className="hero-date">20<span>/</span>10</div>
            <div className="scroll-hint"><ChevronDown /></div>
          </div>
        </section>
        <section className="find-section" aria-labelledby="find-title">
          <div className="eyebrow"><Sparkles strokeWidth={1.3} />Một lời chúc, một người đặc biệt</div>
          <h2 id="find-title">Tìm chút yêu thương của bạn</h2>
          <p className="section-copy">Nhập tên người nhận để mở tấm thiệp dành riêng cho bạn.</p>
          <form className="search-form" onSubmit={(event) => { event.preventDefault(); search(name); }}>
            <div className="input-wrap"><Search strokeWidth={1.5} /><input aria-label="Tên người nhận" aria-describedby={error ? "search-error" : undefined} aria-invalid={Boolean(error)} value={name} onChange={(event) => { setName(event.target.value); setError(""); }} placeholder="Nhập tên người nhận…" autoComplete="off" maxLength={80} /></div>
            <Button variant="romantic" type="submit">Tìm thiệp<ArrowRight /></Button>
          </form>
          <div className="sample-list"><span>Chọn nhanh tên từ danh sách:</span>{greetings.map((sample) => <Button key={sample.name} variant="ghost" className="sample-button" onClick={() => search(sample.name)}>{sample.name}</Button>)}</div>
          {error && <p className="form-error" role="alert" id="search-error">{error}</p>}
        </section>
        <section className="card-section" ref={sectionRef} aria-labelledby="card-title">
          <div className="eyebrow"><Flower2 strokeWidth={1.3} />Gói ghém những điều dịu dàng</div>
          <h2 id="card-title">{opened ? "Một lời chúc dành cho bạn" : "Có một tấm thiệp đang chờ bạn"}</h2>
          <p className="section-copy">Một ngày thật đẹp, dành cho những người bạn thật đáng quý.</p>
          {opened && <div className="template-picker" role="group" aria-label="Chọn mẫu thiệp">
            {cardTemplates.map((option) => <Button key={option.id} variant="ghost" className="template-option" aria-label={option.name} aria-pressed={template.id === option.id} disabled={downloadState === "loading"} onClick={() => { setTemplate(option); setDownloadState("idle"); setDownloadError(""); }}>
              <span className="template-preview"><img src={option.artwork} alt="" width={option.width} height={option.height} loading="lazy" /><span>20 / 10</span></span>
              <span className="template-label">{option.name}</span>
              <Check className="template-check" aria-hidden="true" />
            </Button>)}
          </div>}
          <div className="card-stage" aria-live="polite">
            {opened ? <GreetingCard key={`${recipient.name}-${template.id}`} recipient={recipient} template={template} cardRef={cardRef} /> : <div className="envelope">
              <img src={floralCard} alt="Tấm thiệp hoa đang chờ mở" width={1536} height={1024} loading="lazy" className="envelope-art" />
              <div className="envelope-center"><div className="seal"><Heart strokeWidth={1.4} /></div><p className="envelope-title">Gửi bạn, một chút yêu thương</p><p className="envelope-small">Một bất ngờ nhỏ cho ngày 20/10</p><Button variant="romantic" onClick={() => reveal()}><Mail />Mở thiệp của bạn</Button></div>
            </div>}
          </div>
          {opened && <><div className="card-actions"><Button variant="romantic" onClick={download} disabled={downloadState === "loading"}>{downloadState === "done" ? <Check /> : <Download />}{downloadState === "loading" ? "Đang lưu thiệp…" : downloadState === "done" ? "Tải lại thiệp PNG" : "Tải thiệp PNG"}</Button><Button variant="delicate" onClick={() => { setOpened(false); setDownloadState("idle"); }}><RotateCcw />Đóng thiệp</Button></div><p className="download-note" role="status">{downloadState === "done" ? "Thiệp đã sẵn sàng để lưu giữ và chia sẻ." : "Lưu lại một chút yêu thương, giữ mãi một kỷ niệm đẹp."}</p>{downloadError && <p className="form-error" role="alert">{downloadError}</p>}</>}
        </section>
      </main>
      <footer><span>Được gửi bằng cả trái tim <Heart strokeWidth={1.4} /> · Chúc mừng 20/10</span><span>Bản xem trước · 13 thiệp dành riêng cho những người phụ nữ thân thương</span></footer>
    </>
  );
}
