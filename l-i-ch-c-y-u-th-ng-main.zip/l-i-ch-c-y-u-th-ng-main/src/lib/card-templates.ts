import originalArtwork from "@/assets/floral-card.jpg";
import warmArtwork from "@/assets/card-warm.jpg";
import meadowArtwork from "@/assets/card-meadow.jpg";

export const cardTemplates = [
  { id: "original", name: "Mẫu hiện tại", artwork: originalArtwork, alt: "Hoa hồng và mẫu đơn trang trí thiệp", width: 1536, height: 1024 },
  { id: "warm", name: "Thanh lịch và ấm áp", artwork: warmArtwork, alt: "Hoa hồng hồng đất, cẩm tú cầu trắng và lá xanh trên giấy trắng ngà", width: 1536, height: 1536 },
  { id: "meadow", name: "Tươi sáng và dịu dàng", artwork: meadowArtwork, alt: "Hoa cúc nhỏ và hoa đồng nội hồng đào, lavender trên nền trắng kem", width: 1536, height: 1536 },
] as const;

export type CardTemplate = (typeof cardTemplates)[number];